import math

def  calculate_distance(x1,y1,x2,y2):

    return math.sqrt((x2 - x1 )** 2 + (y2 -y1)** 2)

def main():
    raktar = ()
    coordinates = []
    MAX_SIZE = 125 #Mivel 2500 / 20 = 125 ezert atalakitjuk db szamra mert igy egyszerubb szamolni
    DOBOZ_SIZE = 1
    current_size = 125
    distance = 0
    utvonal = [-1]
    teres_counter = 0
    with open("radar",'r') as f:
        lines = f.readlines()
        raktar = tuple([int(i) for i in lines[0].split(',')])
        #print(f'raktar: {raktar[0]} :: {raktar[1]}')
        for line in lines[1:20]:
            l = [int(i) for i in line.split(',')]
            #print(l)
            coordinates.append(l)

    i = 0
    while(i < 19): #18 mert a 19 az a masik feladat
        print("GPS: ",coordinates[i])
        if(len(utvonal) > 0):
            if(utvonal[-1] == -1):
                distance += calculate_distance(x1=raktar[0],y1=raktar[1],x2=coordinates[i][0],y2=coordinates[i][1])
            else:
                distance += calculate_distance(x1=coordinates[i][0],y1=coordinates[i][1],x2=coordinates[utvonal[-1]][0],y2=coordinates[utvonal[-1]][1])
        utvonal.append(i)
        if current_size < coordinates[i][2]: # hazateres
            print(" current_size < coordinates[i][2]")
            coordinates[i][2] -= current_size
            current_size = MAX_SIZE
            print("raktar: ",raktar)
            teres_counter += 1
            distance += calculate_distance(x1=raktar[0], y1=raktar[1], x2=coordinates[i][0], y2=coordinates[i][1])
            utvonal.append(-1)
            print("I: ",i)
        elif current_size == coordinates[i][2]: # hazateres
            print(" current_size == coordinates[i][2]")
            coordinates[i][2] -= current_size
            current_size = MAX_SIZE
            print("raktar: ",raktar)
            teres_counter += 1
            distance += calculate_distance(x1=raktar[0], y1=raktar[1], x2=coordinates[i][0], y2=coordinates[i][1])
            utvonal.append(-1)
            i += 1
        else:
            print("Else")
            current_size -= coordinates[i][2]
            coordinates[i][2] = 0
            i += 1
        #print("DEBUG", coordinates[i])
        if(i >= 18 and coordinates[18][2] == 0):
            #go home
            teres_counter += 1
            distance += calculate_distance(x1=raktar[0], y1=raktar[1], x2=coordinates[18][0], y2=coordinates[18][1])
            utvonal.append(-1)
            break

    lines = open('radar', 'r').readlines()
    new_last_line = (lines[-1].rstrip() + "," + str(current_size))
    lines[-1] = new_last_line
    open('radar', 'w').writelines(lines)

    print("current: ",current_size)

    print("Teresek szama: ",teres_counter)
    print("Megtet ut kmben: ",distance * 1000 )
    print("Utvonal: ", utvonal)

    #3as
    current_size = 125
    distance = 0
    utvonal = [-1]
    teres_counter = 0
    i = 0
    while (i < 19):  # 18 mert a 19 az a masik feladat
        print("GPS: ", coordinates[i])
        if (len(utvonal) > 0):
            if (utvonal[-1] == -1):
                distance += calculate_distance(x1=raktar[0], y1=raktar[1], x2=coordinates[i][0], y2=coordinates[i][1])
            else:
                distance += calculate_distance(x1=coordinates[i][0], y1=coordinates[i][1],
                                               x2=coordinates[utvonal[-1]][0], y2=coordinates[utvonal[-1]][1])
        utvonal.append(i)
        if current_size < coordinates[i][2]:  # hazateres
            print(" current_size < coordinates[i][2]")
            current_size = MAX_SIZE
            print("raktar: ", raktar)
            teres_counter += 1
            distance += calculate_distance(x1=raktar[0], y1=raktar[1], x2=coordinates[i][0], y2=coordinates[i][1])
            utvonal.append(-1)
            print("I: ", i)
        elif current_size == coordinates[i][2]:  # hazateres
            print(" current_size == coordinates[i][2]")
            coordinates[i][2] -= current_size
            current_size = MAX_SIZE
            print("raktar: ", raktar)
            teres_counter += 1
            distance += calculate_distance(x1=raktar[0], y1=raktar[1], x2=coordinates[i][0], y2=coordinates[i][1])
            utvonal.append(-1)
            i += 1
        else:
            print("Else")
            current_size -= coordinates[i][2]
            coordinates[i][2] = 0
            i += 1
        # print("DEBUG", coordinates[i])
        if (i >= 18 and coordinates[18][2] == 0):
            # go home
            teres_counter += 1
            distance += calculate_distance(x1=raktar[0], y1=raktar[1], x2=coordinates[18][0], y2=coordinates[18][1])
            utvonal.append(-1)
            break

        print("3as -------")
        print("current: ", current_size)

        print("Teresek szama: ", teres_counter)
        print("Megtet ut kmben: ", distance * 1000)
        print("Utvonal: ", utvonal)

if __name__ == '__main__':
    main()

